
import React, { Component, Fragment } from 'react';
import { Container, Header, Grid, Table, Button, Icon, Divider, Form } from '@mes/mes-ui-react';

const user = {
  id: '1',
  email: 'hkkang@nextree.co.kr',
  name: '강형구',
  phone: '010-3210-0446',
  addresses: [
    {city: '서울', zipCode: '12345', address: '봉천동 220-4'},
    {city: '경기도', zipCode: '54321', address: '당동' },
  ]
};

class UserList extends Component {

  render() {
    return (
      <Container style={{marginTop: '5em', marginBottom: '5em'}}>
        <Header as='h1' content={`사용자 > ${user.name || ''}`} textAlign='left' />
        <Divider />

        <Grid>
          <Grid.Row>
            <Grid.Column>
              <Button floated="right">목록</Button>
              <Button positive floated="right">저장</Button>
            </Grid.Column>
          </Grid.Row>
        </Grid>
        <Divider hidden />

        <Form size='large'>
          <Form.Group widths={2}>
            <Form.Field label='이메일' control='input' placeholder='이메일' value={user.email || ''} />
          </Form.Group>
          <Divider hidden />
          <Form.Group widths={2}>
            <Form.Field label='이름' control='input' placeholder='이름' value={user.name || ''} />
            <Form.Field label='전화번호' control='input' placeholder='전화번호' value={user.phone || ''} />
          </Form.Group>
        </Form>

        <Container style={{marginTop: '6em'}}>
          <Grid columns={2}>
            <Grid.Row>
              <Grid.Column>
                <Header as='h3'>
                  <Icon.Group size='small'>
                    <Icon color='blue' name='square full' />
                  </Icon.Group>
                  주소
                </Header>
              </Grid.Column>
              <Grid.Column>
                <Button primary size="small" floated="right">주소등록</Button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
          <Table celled>
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell textAlign='center'>도시</Table.HeaderCell>
                <Table.HeaderCell textAlign='center'>우편번호</Table.HeaderCell>
                <Table.HeaderCell textAlign='center'>상세주소</Table.HeaderCell>
                <Table.HeaderCell textAlign='center'/>
              </Table.Row>
            </Table.Header>

            <Table.Body>
              {
                user.addresses.length > 0 ?
                  user.addresses.map((obj, index) => {
                    return (
                      <Table.Row key={`address_${index}`}>
                        <Table.Cell>{obj.city}</Table.Cell>
                        <Table.Cell>{obj.zipCode}</Table.Cell>
                        <Table.Cell>{obj.address}</Table.Cell>
                        <Table.Cell width={2} textAlign="center"><Button color="grey" size="mini" >삭제</Button></Table.Cell>
                      </Table.Row>
                    )
                  })
                  :
                  <Table.Row>
                    <Table.Cell>데이터가 없습니다.</Table.Cell>
                  </Table.Row>
              }
            </Table.Body>
          </Table>
        </Container>
      </Container>
    )
  }
}

export default UserList;
