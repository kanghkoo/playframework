
import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Container, Header, Divider, Button } from 'semantic-ui-react';

import userApi from '../api/userApi';
import PageHeader from '../shared/PageHeader';
import LineButtons from '../shared/LineButtons';
import UserPop from './UserPopContainer';
import UserTableView from '../view/UserTableView';


@autobind
class UserListContainer extends Component {
  //
  state = {
    users: [],
  };


  componentDidMount() {
    this.findUserList();
  }

  findUserList() {
    userApi.findUserList()
      .then((users) => this.setState({ users }));
  }

  onClickReload() {
    this.findUserList();
  }

  onRouteUser(email) {
    //
    const { routeUserView } = this.props;
    routeUserView({ email });
  }


  render() {
    //
    const { users } = this.state;

    return (
      <Container style={{ margin: '2em' }}>
        <PageHeader text="사용자 목록" />

        <LineButtons>
          <UserPop
            buttonName="등록"
            buttonProps={{ primary: true, floated: 'right' }}
            onConfirm={this.findUserList}
          />
          <Button floated="right" onClick={this.onClickReload}>새로고침</Button>
        </LineButtons>

        <UserTableView
          users={users}
          onRouteUser={this.onRouteUser}
        />
      </Container>
    );
  }
}

export default UserListContainer;
