
import React, { Component } from 'react';
import autobind from 'autobind-decorator';

import UserList from './container/UserListContainer';
import UserDetailView from './container/UserDetailViewContainer';


@autobind
class UserRoute extends Component {
  //
  static pages = {
    'user-list': { component: UserList },
    'user-view': { component: UserDetailView },
  };

  state = {
    page: 'user-list',
    params: {},
  };

  routeUserList(params = {}) {
    this.setState({ page: 'user-list', params });
  }

  routeUserView(params = {}) {
    this.setState({ page: 'user-view', params });
  }


  render() {
    //
    const { page, params } = this.state;
    const PageComponent = UserRoute.pages[page].component;

    return (
      <PageComponent
        routeUserList={this.routeUserList}
        routeUserView={this.routeUserView}
        params={params}
      />
    );
  }
}

export default UserRoute;
