
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind-decorator';
import { Link, withRouter } from 'react-router-dom';
import { Table, Icon } from 'semantic-ui-react';


@autobind
class UserTableView extends Component {
  //
  static propTypes = {
    users: PropTypes.array,
    onRouteUser: PropTypes.func,
  };

  routerUser(userId) {
    //
    const { history } = this.props;
    history.push(`/users/${userId}`);
  }

  render() {
    //
    const { users, routeUserBasePath, onRouteUser } = this.props;

    return (
      <Table celled>
        <Table.Header>
          <Table.Row textAlign="center">
            <Table.HeaderCell>이메일</Table.HeaderCell>
            <Table.HeaderCell>이름</Table.HeaderCell>
            <Table.HeaderCell>전화번호</Table.HeaderCell>
            <Table.HeaderCell>상세보기</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {
            Array.isArray(users) && users.length > 0 ?
              users.map((user) =>
                <Table.Row key={user.id}>
                  <Table.Cell>{user.email}</Table.Cell>
                  <Table.Cell>{user.name}</Table.Cell>
                  <Table.Cell>{user.phone}</Table.Cell>
                  <Table.Cell textAlign='center'>
                    {/*<a onClick={() => onRouteUser(user.id)}><Icon name="angle right" /></a>*/}
                    <a onClick={() => this.routerUser(user.id)}><Icon name="angle right" /></a>
                    {/*<Link to={`${routeUserBasePath}/${user.id}`}><Icon name="angle right" /></Link>*/}
                  </Table.Cell>
                </Table.Row>
              )
              :
              <Table.Row>
                <Table.Cell>등록된 사용자가 없습니다.</Table.Cell>
              </Table.Row>
          }
        </Table.Body>
      </Table>
    );
  }
}

export default withRouter(UserTableView);
