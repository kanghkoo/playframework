
import React, { Component } from 'react';
import autobind from 'autobind-decorator';

import { Container, Button, Divider, Form } from 'semantic-ui-react';

import userApi from '../api/userApi';
import PageHeader from '../shared/PageHeader';
import LineButtons from '../shared/LineButtons';
import UserFormView from '../view/UserFormView';
import UserAddressTableView from '../view/UserAddressTableView';


@autobind
class UserDetailViewContainer extends Component {
  //
  state = {
    user: null,
  };

  componentDidMount() {
    //
    const { match } = this.props;

    userApi.findUser(match.params.userId)
      .then((user) => this.setState({ user }));
  }

  setUserProp(propName, value) {
    //
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [propName]: value,
      },
    });
  }


  render() {
    //
    const { routeUserList } = this.props;
    const { user } = this.state;

    if (!user) {
      return null;
    }

    return (
      <Container style={{ margin: '2em' }}>
        <PageHeader text={`사용자 > ${user.name || ''}`} />

        <LineButtons>
          <Button floated="right" onClick={routeUserList}>목록</Button>
        </LineButtons>
        <Divider hidden />

        <Form size='large'>
          <UserFormView
            user={user}
            onChangeUserProp={this.setUserProp}
          />
        </Form>

        <UserAddressTableView
          addresses={user.addresses}
        />
      </Container>
    );
  }
}

export default UserDetailViewContainer;
