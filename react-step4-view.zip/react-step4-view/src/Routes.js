
import React from 'react';
import { BrowserRouter, Route, Switch, Redirect, } from 'react-router-dom';

import UserList from './user_step4_3/container/UserListContainer';
import UserDetailView from './user_step4_3/container/UserDetailViewContainer';


const Routes = () => (
  <BrowserRouter>
    <Switch>
      <Redirect exact from="/" to="/users" />
      <Route exact path="/users" component={UserList} />
      <Route exact path="/users/:userId" component={UserDetailView} />
    </Switch>
  </BrowserRouter>
);

export default Routes;
