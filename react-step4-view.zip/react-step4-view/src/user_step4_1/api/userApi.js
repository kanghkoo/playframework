
import axios from 'axios';


const basePath = '/user-api';


function registerUser(user) {
  return axios.post(`${basePath}/users`, user)
    .then((response) => response.data);
}

function findUserList() {
  return axios.get(`${basePath}/users`)
    .then((response) => response.data);
}

function findUser(email) {
  return axios.get(`${basePath}/users/${email}`)
    .then((response) => response.data);
}

export default {
  registerUser,
  findUserList,
  findUser,
};
