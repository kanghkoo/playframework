
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind-decorator';
import { Modal, Form, Button } from 'semantic-ui-react';

import userApi from '../api/userApi';
import LineButtons from '../shared/LineButtons';
import UserFormView from '../view/UserFormView';


@autobind
class UserPop extends Component {
  //
  static propTypes = {
    buttonName: PropTypes.string.isRequired,
    buttonProps: PropTypes.object,
    onConfirm: PropTypes.func, // Step 1-2
  };

  static defaultProps = {
    buttonProps: {},
    onConfirm: () => {},
  };


  state = {
    open: false,
    user: {
      name: '',
      email: '',
      phone: '',
    },
  };

  onOpen() {
    this.setState({ open: true });
  }

  onClose() {
    this.setState({ open: false });
  }


  setUserProp(propName, value) {
    //
    const { user } = this.state;

    this.setState({
      user: {
        ...user,
        [propName]: value,
      },
    });
  }

  onClickRegister() {
    //
    const { onConfirm } = this.props;
    const { user } = this.state;
    const invalid = Object.keys(user).some((userProp) => !user[userProp]);

    if (invalid) {
      alert('정보를 모두 입력해 주세요.');
      return;
    }

    userApi.registerUser(user)
      .then(this.onClose) // Step 1-2
      .then(onConfirm)
  }


  render() {
    //
    const { buttonName, buttonProps } = this.props;
    const { open, user } = this.state;

    return (
      <Modal
        trigger={<Button {...buttonProps} onClick={this.onOpen}>{buttonName}</Button>}
        open={open}
        onClose={this.onClose}
      >
        <Modal.Content>
          <Form>
            <UserFormView
              user={user}
              onChangeUserProp={this.setUserProp}
            />

            <LineButtons>
              <Button primary floated="right" onClick={this.onClickRegister}>등록</Button>
              <Button floated="right" onClick={this.onClose}>취소</Button>
            </LineButtons>
          </Form>
        </Modal.Content>
      </Modal>
    );
  }
}

export default UserPop;
