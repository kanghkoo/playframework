
import React, { Component } from 'react';
import autobind from 'autobind-decorator';
import { Table, Icon } from 'semantic-ui-react';


@autobind
class UserListView extends Component {
  //
  render() {
    //
    const { users } = this.props;

    return (
      <Table celled>
        <Table.Header>
          <Table.Row textAlign="center">
            <Table.HeaderCell>이메일</Table.HeaderCell>
            <Table.HeaderCell>이름</Table.HeaderCell>
            <Table.HeaderCell>전화번호</Table.HeaderCell>
            <Table.HeaderCell>상세보기</Table.HeaderCell>
          </Table.Row>
        </Table.Header>

        <Table.Body>
          {
            Array.isArray(users) && users.length > 0 ?
              users.map((user) =>
                <Table.Row key={user.email}>
                  <Table.Cell>{user.email}</Table.Cell>
                  <Table.Cell>{user.name}</Table.Cell>
                  <Table.Cell>{user.phone}</Table.Cell>
                  <Table.Cell textAlign='center'><Icon name="angle right" /></Table.Cell>
                </Table.Row>
              )
              :
              <Table.Row>
                <Table.Cell>등록된 사용자가 없습니다.</Table.Cell>
              </Table.Row>
          }
        </Table.Body>
      </Table>
    );
  }
}

export default UserListView;
