
import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind-decorator';
import { Form } from 'semantic-ui-react';


@autobind
class UserFormView extends Component {
  //
  static propTypes = {
    user: PropTypes.object,
    onChangeUserProp: PropTypes.func,
  };


  onChangeEmail(e) {
    //
    const { onChangeUserProp } = this.props;
    onChangeUserProp('email', e.target.value);
  }

  onChangeName(e) {
    //
    const { onChangeUserProp } = this.props;
    onChangeUserProp('name', e.target.value);
  }

  onChangePhone(e) {
    //
    const { onChangeUserProp } = this.props;
    onChangeUserProp('phone', e.target.value);
  }


  render() {
    //
    const { user } = this.props;

    return (
      <Fragment>
        <Form.Field>
          <label>이메일</label>
          <input placeholder='이메일' value={user.email} onChange={this.onChangeEmail} />
        </Form.Field>

        <Form.Field>
          <label>이름</label>
          <input placeholder="이름" value={user.name} onChange={this.onChangeName} />
        </Form.Field>

        <Form.Field>
          <label>전화번호</label>
          <input placeholder="전화번호" value={user.phone} onChange={this.onChangePhone} />
        </Form.Field>
      </Fragment>
    );
  }
}

export default UserFormView;
