
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import autobind from 'autobind-decorator';

import { Container, Header, Grid, Table, Icon, Button } from 'semantic-ui-react';


@autobind
class UserAddressTableView extends Component {
  //
  static propTypes = {
    addresses: PropTypes.array,
  };

  render() {
    //
    const { addresses } = this.props;

    return (
      <Container style={{ marginTop: '2em' }}>
        <Grid columns={2}>
          <Grid.Row>
            <Grid.Column>
              <Header as='h3'>
                <Icon.Group size='small'>
                  <Icon color='blue' name='square full' />
                </Icon.Group>
                주소
              </Header>
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Table celled>
          <Table.Header>
            <Table.Row textAlign="center">
              <Table.HeaderCell>명칭</Table.HeaderCell>
              <Table.HeaderCell>도시</Table.HeaderCell>
              <Table.HeaderCell>우편번호</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            {
              Array.isArray(addresses) && addresses.length > 0 ?
                addresses.map((address, index) => {
                  return (
                    <Table.Row key={`address_${index}`}>
                      <Table.Cell>{address.name}</Table.Cell>
                      <Table.Cell>{address.city}</Table.Cell>
                      <Table.Cell>{address.zipCode}</Table.Cell>
                    </Table.Row>
                  )
                })
                :
                <Table.Row>
                  <Table.Cell>데이터가 없습니다.</Table.Cell>
                </Table.Row>
            }
          </Table.Body>
        </Table>
      </Container>
    );
  }
}

export default UserAddressTableView;
