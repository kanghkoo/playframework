
import 'semantic-ui-css/semantic.min.css';

import React from 'react';

// step 4-1
import UserList from './user_step4_1/container/UserListContainer';
import UserDetailView from './user_step4_1/container/UserDetailViewContainer';

// step 4-2
import UserRoute from './user_step4_2/UserRoute';

// step 4-3
import Routes from './Routes';


const App = () => (
  <Routes />
);

export default App;
