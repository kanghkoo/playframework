

const commonProperties = {
  app: {
    dir: 'src',
    output: '/dist/common/mes-ui-react',
  },

  entry: {
    app: './src/index.js',
  },
};


module.exports = commonProperties;
