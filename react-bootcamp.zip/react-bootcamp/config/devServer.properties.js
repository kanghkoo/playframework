

const devServerProperties = {
  entry: {
    app: './src/index.js',
  },
  proxy: {
    '/test': {
      target: 'http://test.apps.dkpcf.posco.co.kr',
      pathRewrite: { '/test-api': '' },
      changeOrigin: true,
      secure: false,
    },
  },
};


module.exports = devServerProperties;
